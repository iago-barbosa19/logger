# Logger
---
> O projeto serve para ser um logger próprio, tendo em vista os problemas que o pacote logging pode ter
>
> O projeto foi feito usando Python3.10 e bibliotecas nativas do Python, então é possível rodar em 
> todas as versões do Python.